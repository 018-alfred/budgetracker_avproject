// =========================================
// server.js — Starts a local web server
// =========================================

// Load environment variables from .env file
require('dotenv').config();

const express = require('express');
const path    = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

// Serve all files in the project folder
// (index.html, css/, js/, assets/)
app.use(express.static(path.join(__dirname)));

// When someone visits http://localhost:3000
// send them index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`✅ ${process.env.APP_NAME} running at:`);
  console.log(`   http://localhost:${PORT}`);
});