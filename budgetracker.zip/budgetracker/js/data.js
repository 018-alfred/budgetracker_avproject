/* =========================================
   data.js — Stores and manages expense data
   ========================================= */

// Category colours used across the app
const CAT_COLORS = {
  Housing:       '#378ADD',
  Food:          '#1D9E75',
  Transport:     '#BA7517',
  Health:        '#D4537E',
  Education:     '#7F77DD',
  Entertainment: '#D85A30',
  Shopping:      '#639922',
  Other:         '#888780',
};

// The main list of expenses (stored in memory as an array)
let expenses = [];

/**
 * Add a new expense object to the list.
 * @param {string} name   - Expense label (e.g. "Rent")
 * @param {number} amount - Amount in rupees
 * @param {string} cat    - Category name
 */
function addExpenseData(name, amount, cat) {
  expenses.push({ id: Date.now(), name, amount, cat });
}

/**
 * Remove an expense by its unique id.
 * @param {number} id
 */
function deleteExpenseData(id) {
  expenses = expenses.filter(e => e.id !== id);
}

/**
 * Calculate total of all expenses.
 * @returns {number}
 */
function getTotalExpenses() {
  return expenses.reduce((sum, e) => sum + e.amount, 0);
}

/**
 * Get income value from the input field.
 * @returns {number}
 */
function getIncome() {
  return parseFloat(document.getElementById('income').value) || 0;
}

/**
 * Format a number as Indian Rupees.
 * Example: 50000 => "₹50,000"
 * @param {number} n
 * @returns {string}
 */
function fmt(n) {
  return '₹' + Math.round(n).toLocaleString('en-IN');
}
