/* =========================================
   ui.js — Updates the DOM (what user sees)
   ========================================= */

/**
 * Refresh the three summary metric cards at the top.
 */
function updateMetrics() {
  const income  = getIncome();
  const total   = getTotalExpenses();
  const savings = income - total;

  document.getElementById('m-income').textContent   = fmt(income);
  document.getElementById('m-expenses').textContent = fmt(total);
  document.getElementById('m-savings').textContent  = fmt(savings);

  // Turn savings red if overspent, green if positive
  document.getElementById('m-savings').className =
    'metric-value ' + (savings >= 0 ? 'green' : 'red');
}

/**
 * Re-render the list of expense rows in the DOM.
 */
function renderExpenseList() {
  const el = document.getElementById('expense-list');

  // If no expenses, show a placeholder message
  if (expenses.length === 0) {
    el.innerHTML = '<div class="empty">No expenses added yet. Add one above!</div>';
    return;
  }

  // Build each expense row as HTML
  el.innerHTML = expenses.map(e => `
    <div class="expense-item">
      <div class="expense-left">
        <div class="cat-dot" style="background:${CAT_COLORS[e.cat] || '#888'}"></div>
        <div>
          <div class="expense-name">${e.name}</div>
          <div class="expense-cat">${e.cat}</div>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:4px;">
        <span class="expense-amount">${fmt(e.amount)}</span>
        <button class="del-btn" data-id="${e.id}">×</button>
      </div>
    </div>
  `).join('');

  // Attach delete button listeners after rendering
  el.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      deleteExpenseData(Number(btn.dataset.id));
      refreshAll();
    });
  });
}

/**
 * Master refresh — call this whenever data changes.
 * Updates metrics, expense list, and chart together.
 */
function refreshAll() {
  updateMetrics();
  renderExpenseList();

  const income  = getIncome();
  const total   = getTotalExpenses();
  const savings = income - total;
  renderChart(currentTab, income, total, savings);
}
