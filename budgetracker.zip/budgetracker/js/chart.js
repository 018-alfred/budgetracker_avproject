/* =========================================
   chart.js — Draws charts using Chart.js
   ========================================= */

let chart      = null;    // holds the active Chart.js instance
let currentTab = 'bar';   // tracks which tab is currently selected

/**
 * Main chart renderer — picks which chart to draw based on active tab.
 * @param {string} tab      - 'bar' | 'doughnut' | 'savings'
 * @param {number} income
 * @param {number} total    - total expenses
 * @param {number} savings
 */
function renderChart(tab, income, total, savings) {
  // Always destroy the old chart before drawing a new one
  if (chart) { chart.destroy(); chart = null; }

  const canvas    = document.getElementById('mainChart');
  const legendBox = document.getElementById('legend-box');
  legendBox.innerHTML = '';

  if (tab === 'bar') {
    renderBarChart(canvas, legendBox);

  } else if (tab === 'doughnut') {
    renderDoughnutChart(canvas, legendBox, savings);

  } else if (tab === 'savings') {
    renderSavingsChart(canvas, legendBox, income, total, savings);
  }
}

/* ---------------------------------------------------
   Bar Chart: spending per category
--------------------------------------------------- */
function renderBarChart(canvas, legendBox) {
  const cats   = groupByCategory();
  const labels = Object.keys(cats).length ? Object.keys(cats) : ['(no expenses)'];
  const data   = Object.keys(cats).length ? Object.values(cats) : [0];
  const colors = labels.map(l => CAT_COLORS[l] || '#888');

  // Build custom legend above chart
  legendBox.innerHTML = labels.map((l, i) =>
    `<span><span class="legend-sq" style="background:${colors[i]}"></span>${l}: ${fmt(data[i])}</span>`
  ).join('');

  chart = new Chart(canvas, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Amount',
        data,
        backgroundColor: colors,
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: {
          ticks: { autoSkip: false, maxRotation: 30, font: { size: 12 } },
          grid: { display: false }
        },
        y: {
          ticks: { callback: v => '₹' + v.toLocaleString('en-IN'), font: { size: 11 } },
          grid: { color: '#eee' }
        }
      }
    }
  });
}

/* ---------------------------------------------------
   Doughnut Chart: expense + savings breakdown
--------------------------------------------------- */
function renderDoughnutChart(canvas, legendBox, savings) {
  const cats       = groupByCategory();
  const hasSavings = savings > 0;

  const labels = [...Object.keys(cats), ...(hasSavings ? ['Savings'] : [])];
  const data   = [...Object.values(cats), ...(hasSavings ? [savings] : [])];
  const colors = [
    ...Object.keys(cats).map(l => CAT_COLORS[l] || '#888'),
    ...(hasSavings ? ['#1D9E75'] : [])
  ];

  if (labels.length === 0) return;

  legendBox.innerHTML = labels.map((l, i) =>
    `<span><span class="legend-sq" style="background:${colors[i]}"></span>${l}: ${fmt(data[i])}</span>`
  ).join('');

  chart = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: colors,
        borderWidth: 2,
        borderColor: '#fff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '62%',
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: ctx => ` ${fmt(ctx.raw)}` } }
      }
    }
  });
}

/* ---------------------------------------------------
   Savings Chart: income vs expenses vs savings
--------------------------------------------------- */
function renderSavingsChart(canvas, legendBox, income, total, savings) {
  legendBox.innerHTML = `
    <span><span class="legend-sq" style="background:#378ADD"></span>Income: ${fmt(income)}</span>
    <span><span class="legend-sq" style="background:#D85A30"></span>Expenses: ${fmt(total)}</span>
    <span><span class="legend-sq" style="background:#1D9E75"></span>Savings: ${fmt(Math.max(0, savings))}</span>
  `;

  chart = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: ['This month'],
      datasets: [
        { label: 'Income',   data: [income],               backgroundColor: '#378ADD', borderRadius: 6 },
        { label: 'Expenses', data: [total],                backgroundColor: '#D85A30', borderRadius: 6 },
        { label: 'Savings',  data: [Math.max(0, savings)], backgroundColor: '#1D9E75', borderRadius: 6 },
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false } },
        y: {
          ticks: { callback: v => '₹' + v.toLocaleString('en-IN'), font: { size: 11 } },
          grid: { color: '#eee' }
        }
      }
    }
  });
}

/* ---------------------------------------------------
   Helper: group expenses by category and sum amounts
--------------------------------------------------- */
function groupByCategory() {
  const cats = {};
  expenses.forEach(e => {
    cats[e.cat] = (cats[e.cat] || 0) + e.amount;
  });
  return cats;
}
