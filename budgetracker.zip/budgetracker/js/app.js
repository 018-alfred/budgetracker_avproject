/* =========================================
   app.js — Entry point, wires up all events
   ========================================= */

/* ---------------------------------------------------
   1. Add Expense — button click handler
--------------------------------------------------- */
document.getElementById('add-btn').addEventListener('click', () => {
  const name   = document.getElementById('exp-name').value.trim();
  const amount = parseFloat(document.getElementById('exp-amount').value);
  const cat    = document.getElementById('exp-cat').value;

  // Validate: name must not be empty
  if (!name) {
    alert('Please enter an expense name.');
    return;
  }

  // Validate: amount must be a positive number
  if (isNaN(amount) || amount <= 0) {
    alert('Please enter a valid amount greater than 0.');
    return;
  }

  // Save to data layer and refresh the UI
  addExpenseData(name, amount, cat);

  // Clear the form inputs after adding
  document.getElementById('exp-name').value   = '';
  document.getElementById('exp-amount').value = '';

  refreshAll();
});

/* ---------------------------------------------------
   2. Income input — refresh when user changes value
--------------------------------------------------- */
document.getElementById('income').addEventListener('input', refreshAll);

/* ---------------------------------------------------
   3. Chart tab buttons — switch between chart views
--------------------------------------------------- */
document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {

    // Remove 'active' from all tabs, add to clicked one
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');

    // Update which tab is currently active (used by refreshAll)
    currentTab = btn.dataset.tab;

    // Redraw the chart for the new tab
    const income  = getIncome();
    const total   = getTotalExpenses();
    const savings = income - total;
    renderChart(currentTab, income, total, savings);
  });
});

/* ---------------------------------------------------
   4. Initial render on page load
--------------------------------------------------- */
refreshAll();
